package com.example.books;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;
    private List<BookDTO> books;

    public List<JSONObject> allBooks() {
        return bookRepository.findAll();
    }

    public Optional<JSONObject> singleBook(ObjectId id) {
        return bookRepository.findById(id);
    }

    public void createBook(JSONObject book) {
    }

    public Book findByIsbn(String isbn) {
        return null;
    }

    public List<BookDTO> getBooks() {
        return books;
    }

    public void setBooks(List<BookDTO> books) {
        this.books = books;
    }
}
