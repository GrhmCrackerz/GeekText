package com.example.books;


import org.bson.types.ObjectId;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/v1/book")
public class BookController {

    @Autowired
    private BookService bookService;
    private JSONObject Book;

    @GetMapping
    public ResponseEntity<List<JSONObject>> getAllBooks() {
        return new ResponseEntity<List<JSONObject>>(bookService.allBooks(), HttpStatus.OK);
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<Optional<JSONObject>> getSingleBook(@PathVariable ObjectId id) {
        return new ResponseEntity<Optional<JSONObject>>(bookService.singleBook(id), HttpStatus.OK);
    }


    private final BookRepository bookRepository;

    public BookController(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @PostMapping
    public ResponseEntity<Void> createBook(@RequestBody Book book) {
        BookRepository.save(book);
        return ResponseEntity.ok().build();
    }



    @GetMapping("/isbn/{isbn}")
    public ResponseEntity<JSONObject> getBookByIsbn(@PathVariable String isbn) {
        String bookJson = bookRepository.findBookJsonByIsbn(isbn);
        org.json.JSONObject bookObj = null;
        try {
            bookObj = new org.json.JSONObject(bookJson);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        JSONObject book = new JSONObject(bookObj);
        return ResponseEntity.ok(book);
    }
    @GetMapping("/book")
    public ResponseEntity<List<BookDTO>> getBooks() {
        List<BookDTO> books = bookService.getBooks();
        if (books.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

}

