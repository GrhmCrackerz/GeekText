package com.example.books;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.JSONObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;

import java.util.ArrayList;
import java.util.List;

@Document(collection = "book")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Book {

    @Id
    private String id;

    private String bookISBN;

    private String title;

    private String author;

    private ArrayList<String> genre;

    private String copiesSold;

    private String publisher;

    private double discount;

    private String yearPublished;

    private String bookDescription;

    @DocumentReference
    private List<Rating> rating;

    public Book(BookDTO bookDTO) {

    }

    public Book(JSONObject bookObj) {

    }

    public Book(com.example.books.JSONObject book) {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getBookIsbn() {
        return bookISBN;
    }

    public void setBookIsbn(String isbn) {
        this.bookISBN = isbn;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

}




