package com.example.books;

public class JSONObject {

    private String isbn;
    private String name;
    private String description;
    private double price;
    private String author;
    private String genre;
    private String publisher;
    private int yearPublished;
    private int copiesSold;

    public JSONObject(Book bookDTO) {
    }

    public JSONObject(org.json.JSONObject json) {

    }
}